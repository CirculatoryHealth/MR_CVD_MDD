#!/bin/bash
#
/hpc/local/CentOS7/dhl_ec/software/GWASToolKit/gwastoolkit.wrapper.sh /hpc/dhl_ec/projects/lookups/AE_TEMPLATE/SNP/gwastoolkit.conf SMC_rankNorm 
