#!/bin/bash
#
/hpc/local/CentOS7/dhl_ec/software/GWASToolKit/gwastoolkit.cleaner.sh /hpc/dhl_ec/projects/lookups/AE_TEMPLATE/SNP/gwastoolkit.conf MastCells_rankNorm 
