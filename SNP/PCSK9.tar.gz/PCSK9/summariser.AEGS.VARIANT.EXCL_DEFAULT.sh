#!/bin/bash
#
/hpc/local/CentOS7/dhl_ec/software/GWASToolKit/summariser.sh /hpc/dhl_ec/projects/lookups/AE_TEMPLATE/SNP/gwastoolkit.conf 
