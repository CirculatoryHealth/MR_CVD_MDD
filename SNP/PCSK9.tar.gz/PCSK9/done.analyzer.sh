#!/bin/bash
#
echo "FINISHED analyzer.sh! Now the QC can start!"
